/* 
 * File:   main.cpp
 * Author: Jose Navarro
 * Created on January 8, 2014, 7:33 PM
 * Savitch_8th Edition, Chapter 1, Problem 8
 * Converting Change to Total Cents
 */

//System Libraries 
#include <iostream>
using namespace std;
//Global Constants
const float CNV_Quartrs_Cnts=2.5e1;
const float CNV_Dimes_Cnts=1e1;
const float CNV_Nckls_Cnts=.5e1;
//Execution Begins Here
int main(int argc, char** argv) {
    //Declaration of Variables 
    float qCount, dCount, nCount, totCnts,cntsMod;
    //Input the amount of Quarters
    cout<<"After each input press \"Enter\""<<endl;
    cout<<"How many Quarters do you have? ";
    cin>>qCount;
    cout<<endl;
    //Input the amount of Dimes
    cout<<"How many Dimes do you have? ";
    cin>>dCount;
    cout<<endl;
    //Input the amount of Nickels
    cout<<"How many Nickels do you have? ";
    cin>>nCount;
    cout<<endl;
    //Process - Convert Quarters,Dimes,and Nickels to Cents
    qCount=qCount*CNV_Quartrs_Cnts;
    dCount=dCount*CNV_Dimes_Cnts;
    nCount=nCount*CNV_Nckls_Cnts;
    totCnts=qCount+dCount+nCount;
    //Output the Conversion Total in Cents
    cout<<"Your total change is: "<<totCnts<<"cents"<<endl;
    //Exit
    return 0;
}

