/* 
 * File:   main.cpp
 * Author:Jose Navarro
 * Created on January 7, 2014, 9:08 PM
 * Savitch, Eight Edition, Chapter 1, Problem 5
 * 1)Calculates the sum and product of two integers
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare variables
    int intgr1, intgr2, sumInt, prodInt;
    //Input the the first integer
    cout<<"Input the first integer and press \"Enter\""<<endl;
    cin>>intgr1;
    //Input the second integer
    cout<<"Input the second integer and press \"Enter\""<<endl;
    cin>>intgr2;
    //Process - calculate the Sum and Product of both integers
    sumInt=intgr1+intgr2;
    prodInt=intgr1*intgr2;
    //Output the Sum and Product of both integers
    cout<<"The Sum of " <<intgr1<< " + "<<intgr2<< " is " << sumInt<<endl;
    cout<<"The Product of " <<intgr1<< " x "<<intgr2<< " is " <<prodInt<<endl;
    //Exit
    return 0;
}

