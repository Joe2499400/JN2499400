/* 
 * File:   main.cpp
 * Author:Jose Navarro
 * Created on January 8, 2014, 6:26 PM
 * Savitch Eight Edition, Chapter 1, problem 7
 * Output CS! Logo using characters "C","S",and "!"
 */

//System Libraries 
#include <iostream>
using namespace std;

//Global Constant

//Function Prototypes

//Execution Starts Here!
int main(int argc, char** argv) {
    //Output CS! Logo
    cout<<"*********************************************"<<endl;
    cout<<endl;
    cout<<"     C C C        S S S S           !!        "<<endl;
    cout<<"   C       C     S        S         !!        "<<endl;
    cout<<"  C             S                   !!        "<<endl;
    cout<<" C               S                  !!        "<<endl;
    cout<<" C                S S S S           !!        "<<endl;
    cout<<" C                         S        !!        "<<endl;
    cout<<"  C                         S       !!        "<<endl;
    cout<<"   C       C      S        S                  "<<endl;
    cout<<"     C C C          S S S           00        "<<endl;
    cout<<endl;
    cout<<"**********************************************"<<endl;
    cout<<endl;
    cout<<       "Computer Science is Cool Stuff!!!"<<endl;

   
    
    //Exit
    return 0;
}

