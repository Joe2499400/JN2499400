/* 
 * File:   main.cpp
 * Author: Jose Navarro
 * Created on January 7, 2014, 8:31 AM
 * Savitch 8th Edition, Chapter 1, Problem 9
 * Calculate Freefall 
 */
//System Libraries
#include <iostream>
using namespace std;

//Global Constant
const float GRAVITY=32.174;

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    float time, frefall;
    //Input the time
    cout<<"Input the time in seconds ";
    cin>>time;
    //calculate the distance dropped
    //*No Good! frefall=GRAVITY*time*time;
    frefall=GRAVITY*time*time*1/2;
    //output the result
    cout<<"The distance Dropped = " <<frefall<<" (ft)"<<endl;
    //Exit Stage Right
    return 0;
            
            
    return 0;
}

