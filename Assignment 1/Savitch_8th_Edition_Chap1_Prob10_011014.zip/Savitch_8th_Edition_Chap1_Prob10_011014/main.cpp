/* 
 * File:   main.cpp
 * Author: Jose Navarro
 * Created on January 8, 2014, 9:41 PM
 * Savitch 8th Edition, Chapter 1, Problem 10
 * Output "C" logo with character of choice
 */

//System Libraries 
#include <iostream>
using namespace std;

//Global Constant

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    char symC;
    //Input Character of choice
    cout<<"Choose a character of your choice: ";
    cin>>symC;
    //Output Symbol 
    cout<<endl;
    cout<<" "<<" "<<" "<<symC<<" "<<symC<<" "<<symC<<endl;
    cout<<" "<<" "<<symC<<"     "<<symC<<endl;
    cout<<" "<<symC<<endl;
    cout<<" "<<symC<<endl;
    cout<<" "<<symC<<endl;
    cout<<" "<<symC<<endl;
    cout<<" "<<symC<<endl;
    cout<<" "<<" "<<symC<<"     "<<symC<<endl;
    cout<<" "<<" "<<" "<<symC<<" "<<symC<<" "<<symC<<endl;
    //Exit
    return 0;
}

